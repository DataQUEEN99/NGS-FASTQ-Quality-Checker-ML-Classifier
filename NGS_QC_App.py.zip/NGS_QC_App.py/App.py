import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pickle
import base64

st.title("🧬 NGS Quality Checker + ML Classifier")
st.write("Upload FASTQ file to analyze read quality using Phred33 and ML.")

# -------------------- Parse FASTQ ------------------------
def load_fastq(file):
    sequences = []
    qualities = []
    lines = file.read().decode().splitlines()
    for i in range(0, len(lines), 4):
        seq = lines[i+1].strip()
        qual = lines[i+3].strip()
        sequences.append(seq)
        qualities.append(qual)
    return sequences, qualities

def ascii_to_phred(q):
    return [ord(c) - 33 for c in q]

def compute_metrics(sequences, qualities):
    metrics = {'avg_phred': [], 'gc_content': [], 'read_length': []}
    for seq, qual in zip(sequences, qualities):
        phred = ascii_to_phred(qual)
        avg_q = np.mean(phred)
        gc = (seq.count("G") + seq.count("C")) / len(seq) * 100
        metrics['avg_phred'].append(avg_q)
        metrics['gc_content'].append(gc)
        metrics['read_length'].append(len(seq))
    return pd.DataFrame(metrics)

# -------------------- File Upload ------------------------
uploaded_file = st.file_uploader("Upload FASTQ file", type=["fastq", "txt"])
if uploaded_file:
    sequences, qualities = load_fastq(uploaded_file)
    st.success(f"Loaded {len(sequences)} reads successfully!")
    df = compute_metrics(sequences, qualities)
    st.dataframe(df.head())

    # -------------------- Visualizations ------------------
    st.subheader("📊 Read Length Distribution")
    fig, ax = plt.subplots()
    ax.hist(df['read_length'])
    st.pyplot(fig)

    st.subheader("📊 Average Read Quality Distribution")
    fig, ax = plt.subplots()
    ax.hist(df['avg_phred'])
    st.pyplot(fig)

    st.subheader("📊 GC Content Distribution")
    fig, ax = plt.subplots()
    ax.hist(df['gc_content'])
    st.pyplot(fig)

    # -------------------- ML Prediction -------------------
    st.subheader("🤖 ML-Based Read Quality Classification")
    try:
        model = pickle.load(open("ml_model.pkl", "rb"))
        preds = model.predict(df[['avg_phred', 'gc_content', 'read_length']])
        df['Quality_Class'] = preds
        st.dataframe(df.head())
        st.write("High vs Low Quality Reads:")
        st.bar_chart(df['Quality_Class'].value_counts())
    except:
        st.warning("ML model not found. Train it first and add 'ml_model.pkl'.")

    # -------------------- Download Report -----------------
    st.subheader("⬇ Download Report")
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="qc_report.csv">Download QC Report</a>'
    st.markdown(href, unsafe_allow_html=True)
