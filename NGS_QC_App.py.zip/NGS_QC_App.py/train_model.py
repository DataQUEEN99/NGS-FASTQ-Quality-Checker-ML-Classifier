import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import pickle

# Example training dataset (replace with real data if available)
df_train = pd.DataFrame({
    'avg_phred': [35, 28, 20, 32, 15],
    'gc_content': [50, 45, 60, 55, 40],
    'read_length': [100, 100, 80, 90, 75],
    'label': ['High', 'High', 'Low', 'High', 'Low']
})

X = df_train[['avg_phred', 'gc_content', 'read_length']]
y = df_train['label']

model = RandomForestClassifier()
model.fit(X, y)

# Save the trained model
pickle.dump(model, open("ml_model.pkl", "wb"))
print("ML model saved as ml_model.pkl")
